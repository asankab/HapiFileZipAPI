'use strict';

const Hapi = require('hapi');
var archiver = require('archiver');

const server = new Hapi.Server();
server.connection({ port: 3000 });

server.route({
    method: 'GET',
    path: '/',
    handler: function (request, reply) {
        reply('Hello, world!');
    }
});

server.route({
    method: 'GET',
    path: '/{name}',
    handler: function (request, reply) {
        reply('Hello, ' + encodeURIComponent(request.params.name) + '!');
    }
});

server.route({
    method: 'GET',
    path: '/zip',
    handler: function (request, reply) {
        //reply('Hello, ' + encodeURIComponent(request.params.name) + '!');

        var fs = require('fs');
        var outputPath = __dirname + '/example.zip';
        var sourcePath = '/home/asankab/epub';

        var output = fs.createWriteStream(outputPath);
        var zipArchive = archiver('zip');

        output.on('close', function () {
            console.log('done with the zip', outputPath);
        });

        zipArchive.pipe(output);

            zipArchive.bulk([
                {src: ['**/*'], cwd: sourcePath, expand: true}
            ]);

        zipArchive.finalize(function (err, bytes) {

            if (err) {
                throw err;
            }

            console.log('done:', base, bytes);

        });

        reply();
    }
});

server.start((err) => {

    if (err) {
        throw err;
    }
    console.log(`Server running at: ${server.info.uri}`);
});